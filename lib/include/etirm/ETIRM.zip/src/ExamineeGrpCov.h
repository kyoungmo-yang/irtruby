/*! \file ExamineeGrpCov.h
 
  \brief
  This class is a descendant of Examinee which also contains information 
  about the group the examinee belongs to (a group covariate).

  Estimation Toolkit for Item Response Models (ETIRM)
  http://www.smallwaters.com/software/cpp/etirm.html 

  Author(s): Brad Hanson (http://www.b-a-h.com/)
  See the file LICENSE for information on usage and redistribution.

  Author(s): 
  Werner Wothke, maintenance (http://www.smallwaters.com)
  Brad Hanson (http://www.b-a-h.com/)
  See the file LICENSE for information on usage and redistribution.

  Copyright (C) 2008, Werner Wothke
  Copyright (c) 2000-2001, Bradley A. Hanson
 */

#ifndef ETIRM_EXAMINEEGRPCOV_H_
#define ETIRM_EXAMINEEGRPCOV_H_

#ifdef ETIRM_NO_DIR_PREFIX
#include "Examinee.h"
#else
#include "etirm/Examinee.h"
#endif

namespace etirm
{

  /*! 
   \brief
    This class is a descendant of Examinee which also contains information 
    about the group the examinee belongs to (a group covariate).

    \section template_args Template Parameters
   
    \param P  Type for storing vector of posterior probabilities
    \param R  Type for storing vector of item responses.  
   */
  template <class R, class P>
#ifndef BOOST_MSVC
  class ExamineeGrpCov : public Examinee<R,P>
#else
  class ExamineeGrpCov : public Examinee<typename R, typename P>
#endif
  {

public:
    //! Group identifier type.
    typedef short group_type;

    /*!
      \brief
      Class constructor.
      
      \section function_args Function Parameters
         
      \param[in] nitems number of items in response string
      \param[in] group  group number (where first group is group 1)
     */
    ExamineeGrpCov(int nitems = 0, group_type group = 1) :
      mGroup(group), Examinee<R, P>(nitems)
    {
    }
    
    /*!
      \brief
      Returns the group which the examinee belongs to.
      
      Return value: group number (where first group is group 1).
     */
    group_type Group() const
    {
      return mGroup;
    }
    /*!
      \brief
      Assigns the group which examinee belongs to.
      
      \section function_args Function Parameters
       
      \param[in] group  Group number (where first group is group 1).
     */
    void SetGroup(int group);

protected:

    group_type mGroup;
    //!< Group which the examinee belongs to (first group is group 1).

  };

  /*
    \brief
    Assigns the group which the examinee belongs to.

    \section function_args Function Parameters
         
    \param[in] group  Group number (where first group is group 1).
   */
  template <class R, class P> void ExamineeGrpCov<R, P>::SetGroup(int group)
  {
    if (group < 1)
      throw InvalidArgument("Invalid group number", "ExamineeGrpCov::SetGroup");
    mGroup = group;
  }

} // namespace etirm

#endif // ETIRM_EXAMINEEGRPCOV_H_
