/*! \file SimulateResponses.h
 
  \brief 
  Simulate responses to items.

  Estimation Toolkit for Item Response Models (ETIRM)
  http://www.smallwaters.com/software/cpp/etirm.html

  Author(s): 
  Werner Wothke, maintenance (http://www.smallwaters.com)
  Brad Hanson (http://www.b-a-h.com/)
  See the file LICENSE for information on usage and redistribution.

  Copyright (C) 2008, Werner Wothke
  Copyright (c) 2000-2001, Bradley A. Hanson
 */

#ifndef ETIRM_SIMULATERESPONSES_H_
#define ETIRM_SIMULATERESPONSES_H_

#ifdef ETIRM_NO_DIR_PREFIX
#include "etirmtypes.h"
#else
#include "etirm/etirmtypes.h"
#endif

namespace etirm
{

  /*!
    \brief
    Simulate responses to a set of items for a specific latent variable value.
   
    \section template_args Template Parameter
   
    \param  II	Type of iterator over items (iterator over pointers to Item objects)
    \param  T	Type of latent variable.
    \param  R	Type of function object for generating random numbers in the interval (0,1).
    \param  RI	Type of iterator over responses.

    \section function_args Function Parameters
   
    \param[in]  item_begin  Iterator pointing to first item.
    \param[in]  item_end  Iterator pointing to one past last item.
    \param[in]  &theta  Value of latent variable for which response will be generated.
    \param[in]  &rand Uniform (0,1) random number generator.
    \param[out] iresp Iterator pointing to first response to be generated.
    \param[in]  resp_indices - If true generate integer response indices, rather than
       responses of type Response, The integer index for the first response
       category is zero, the integer index for the second response category
       is is one, etc. If true then the type RI must be an interator over a
       container of integers, otherwise RI should be an interator over a
       container of type Response. 
   */
  template <class II, class T, class R, class RI> void SimulateResponses(II item_begin,
      II item_end, T &theta, R &rand, RI iresp, bool resp_indices=false)
  {
    std::vector<Real> prob;
    for (; item_begin != item_end; ++item_begin, ++iresp)
    {
      int ncat = (*item_begin)->NumRespCat();
      prob.resize(ncat);
      (*item_begin)->ProbRespAll(theta, prob.begin());

      // compute cumulative probabilities
      std::vector<Real>::iterator ip = prob.begin()+1;
      int i = ncat - 2;
      while (i--)
      {
        *ip += ip[-1];
        ++ip;
      }
      *ip = 1.0; // last cumulative probability should be 1

      // Generate response by finding first cumulative probability
      // greater than a random number
      Real r = rand();
      i = 0;
      ip = prob.begin();
      while (*ip <= r)
      {
        ++ip;
        ++i;
      }

      *iresp = (resp_indices) ? i : (*item_begin)->IndexResponse(i);
    }
  }

} // namespace etirm

#endif // ETIRM_SIMULATERESPONSES_H_
