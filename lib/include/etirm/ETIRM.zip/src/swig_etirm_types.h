/*! \file swig_etirm_types.h

  \brief
  Definition of types that are referenced in swig_etirm.h.
 
  Estimation Toolkit for Item Response Models (ETIRM)
  http://www.smallwaters.com/software/cpp/etirm.html
 
  Author(s): 
  Werner Wothke, maintenance (http://www.smallwaters.com)
  Brad Hanson (http://www.b-a-h.com/)
  See the file LICENSE for information on usage and redistribution.

  Copyright (C) 2008, Werner Wothke
  Copyright (c) 2000-2001, Bradley A. Hanson
 */

#ifndef SWIG_ETIRM_TYPES_H_
#define SWIG_ETIRM_TYPES_H_

#ifdef ETIRM_NO_DIR_PREFIX
#include "etirmtypes.h"
#include "ItemNR.h"
#include "DiscreteLatentDist.h"
#include "ExamineeGrpCov.h"
#else
#include "etirm/etirmtypes.h"
#include "etirm/ItemNR.h"
#include "etirm/DiscreteLatentDist.h"
#include "etirm/ExamineeGrpCov.h"
#endif

// for random number generator (http://www.boost.org)
#include <boost/random/mersenne_twister.hpp>

// SWIG cannot handle the template arguments
#ifndef SWIG

//! Vector of item responses
typedef SCPPNT::Vector<etirm::Response> ResponseVector;

//! Class to hold information about discrete latent variable distribution
typedef etirm::DiscreteLatentDist<etirm::Real> lvdist_type;

//! Class to hold information about examinees
typedef etirm::ExamineeGrpCov<ResponseVector, etirm::RealVector> examinee_type;

/*!
  \brief
  Type used for array of items.
 
  Using ItemNR allows different items to be modeled by different classes 
  descendent from ItemNR (e.g., the 3PL model could be used for some items, 
  and the 2PL model used for other items).
 */
typedef etirm::ItemNR<lvdist_type> item_type;

/*!
  \brief
  Use the Mersenne Twister (http://www.math.keio.ac.jp/matumoto/emt.html)
  from the Boost random number library (http://www.boost.org/libs/random/index.html) 
  as random number generator for bootstrap samples.
 */
typedef boost::mt19937 random_type;

#endif // SWIG
#endif
