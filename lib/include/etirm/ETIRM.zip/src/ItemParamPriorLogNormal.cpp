/*! \file ItemParamPriorLogNormal.cpp
 
  \brief
  Class derived from ItemParamPrior representing a lognormal prior distribution
  of item parameters for use in Bayes modal estimation.
 
  mParameter[0] = mean parameter of lognormal distribution
  mParameter[1] = standard deviation parameter of lognormal distribution.
  
  Note the second parameter is the standard deviation, NOT the variance.

  Estimation Toolkit for Item Response Models (ETIRM)
  http://www.smallwaters.com/software/cpp/etirm.html

  Author(s): 
  Werner Wothke, maintenance (http://www.smallwaters.com)
  Brad Hanson (http://www.b-a-h.com/)
  See the file LICENSE for information on usage and redistribution.

  Copyright (C) 2008, Werner Wothke
  Copyright (c) 2000-2001, Bradley A. Hanson
 */

#ifdef ETIRM_NO_DIR_PREFIX
#include "ItemParamPriorLogNormal.h"
#else
#include "etirm/ItemParamPriorLogNormal.h"
#endif

#include <cmath> // for log
// for compilers which do not put C library functions in std namespace
#ifdef BOOST_NO_STDC_NAMESPACE
namespace std
{ using ::log;}
#endif

namespace etirm
{

  /*!
    \brief
   	Constructor taking vector of parameters.
   	
   	\param[in] &param Parameter vector describing log-Normal prior: param[0] - prior mean, param[1] - prior standard deviation. 

    Note: The second element of param is the standard deviation, NOT the variance.
   */
  ItemParamPriorLogNormal::ItemParamPriorLogNormal(RealVector &param) :
    ItemParamPrior(param)
  {
    variance = param(2) * param(2);
  }

  /*!
    \brief
    Constructor taking prior mean and standard deviation as arguments.
    
    \param[in] mean Prior mean
    \param[in] sd Prior standard deviation
    
    Note: The second parameter is the standard deviation, NOT the variance.
   */ 
  ItemParamPriorLogNormal::ItemParamPriorLogNormal(Real mean, Real sd) :
    ItemParamPrior(2)
  {
    if (sd <= 0.0)
      throw RuntimeError("Invalid s.d. for lognormal prior",
          "ItemParamPriorLogNormal::ItemParamPriorLogNormal");

    mParameters[0] = mean;
    mParameters[1] = sd;

    variance = sd * sd;
  }

  /*!
    \brief
    Default constructor - assigns uniform distribution.
   */
  ItemParamPriorLogNormal::ItemParamPriorLogNormal() :
    ItemParamPrior(2)
  {
    mParameters[0] = 0.0;
    mParameters[1] = 1.0;

    variance = 1.0;
  }

  /*!
    \brief
    Returns log-density of p.
    
    \param[in] p  Argument of log density function (an item parameter value).
    
    Note: Returns only the part of the log of the density that depends on the parameter.
   */
  Real ItemParamPriorLogNormal::LogDensity(Real p)
  {
    /* Check for value outside limits of distribution */
    if (ItemParamPriorLogNormal::ZeroDensity(p))
    {
      return std::log(0.0);
    }

    Real value = std::log(p) - mParameters[0];
    value *= value;
    value /= -2.0 * variance;
    value -= std::log(p);

    return value;
  }

  /*!
    \brief
    Returns first derivative of log density.

    \param[in] p  Argument of log density function (an item parameter value).
  
    Note: Returns only the part of the log of the density that depends on the parameter.
   */
  Real ItemParamPriorLogNormal::DerivLogDensity1(Real p)
  {
    /* Outside limits of distribution density does not change,
     so derivative is zero */
    if (ItemParamPriorLogNormal::ZeroDensity(p))
      return 0.0;

    Real value = std::log(p) - mParameters[0] + variance;
    value /= variance * p;

    return -value;
  }

  /*!
    \brief
    Returns second derivative of log density.

    \param[in] p  Argument of log density function (an item parameter value).

    Note: Returns 0nly the part of the log of the density that depends on the parameter.
   */
  Real ItemParamPriorLogNormal::DerivLogDensity2(Real p)
  {
    /* Outside limits of distribution density does not change,
     so derivative is zero */
    if (ItemParamPriorLogNormal::ZeroDensity(p))
      return 0.0;

    Real value = std::log(p) - mParameters[0] + variance - 1.0;
    value /= p * p * variance;

    return value;
  }

} // namespace etirm
