/*! \file ItemParamPriorBeta4.h
 
  \brief 
  Class representing a four-parameter beta prior distribution of item parameters
  in Bayes modal estimation.

  Estimation Toolkit for Item Response Models (ETIRM)
  http://www.smallwaters.com/software/cpp/etirm.html

  Author(s): 
  Werner Wothke, maintenance (http://www.smallwaters.com)
  Brad Hanson (http://www.b-a-h.com/)
  See the file LICENSE for information on usage and redistribution.

  Copyright (C) 2008, Werner Wothke
  Copyright (c) 2000-2001, Bradley A. Hanson
 */

#ifndef ETIRM_ITEMPARAMPRIORBETA4_H_
#define ETIRM_ITEMPARAMPRIORBETA4_H_

#ifdef ETIRM_NO_DIR_PREFIX
#include "ItemParamPrior.h"
#else
#include "etirm/ItemParamPrior.h"
#endif

namespace etirm
{
  /*!   
    \brief 
    Class representing a four-parameter beta prior distribution of item parameters
    in Bayes modal estimation.
   */
  class ItemParamPriorBeta4 : public ItemParamPrior
  {
public:

    ItemParamPriorBeta4();
    ItemParamPriorBeta4(RealVector &param);
    ItemParamPriorBeta4(Real a, Real b, Real l, Real u);

    //! Returns number of prior beta distribution parameters for the IRT parameter.
    virtual int NumParameters()
    {
      return 4;
    }
    
    
    virtual bool ZeroDensity(Real p)
    {
      return (p <= mParameters[2] || p >= mParameters[3]);
    }
    //!< Returns true if density at p is zero

    virtual Real NearestNonZero(Real x);
    //!< If density of x is zero, then this function will return the value closest to x that has a non-zero density.

    virtual Real LogDensity(Real p);
    // Returns log of the density function.

    virtual Real DerivLogDensity1(Real p);
    // Returns the first derivative of the log density.

    virtual Real DerivLogDensity2(Real p);
    // Returns the second derivative of the log density.

    virtual std::string DistributionName() const
    {
      return std::string("beta");
    }
    //!< Returns string containing name of distribution used for prior.


  };

} // namespace etirm

#endif // ETIRM_ITEMPARAMPRIORBETA4_H_
