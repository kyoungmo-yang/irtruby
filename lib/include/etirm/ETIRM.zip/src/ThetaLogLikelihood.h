/*! \file ThetaLogLikelihood.h
 
  \brief
  Function object for computing loglikelihood for theta parameter
  of an IRT model.

  Estimation Toolkit for Item Response Models (ETIRM)
  http://www.smallwaters.com/software/cpp/etirm.html

  Author(s): 
  Werner Wothke, maintenance (http://www.smallwaters.com)
  Brad Hanson (http://www.b-a-h.com/)
  See the file LICENSE for information on usage and redistribution.

  Copyright (C) 2008, Werner Wothke
  Copyright (c) 2000-2001, Bradley A. Hanson
 */

#ifndef ETIRM_THETALOGLIKELIHOOD_H_
#define ETIRM_THETALOGLIKELIHOOD_H_

#ifdef ETIRM_NO_DIR_PREFIX
#include "etirmtypes.h"
#else
#include "etirm/etirmtypes.h"
#endif

#include <cmath> // for log
#ifdef BOOST_NO_STDC_NAMESPACE
// for compilers which do not put C library functions in std namespace
namespace std
{ using ::log;}
#endif

namespace etirm
{

  /*!
    \brief
    Function object for computing loglikelihood for theta parameter of an IRT model.

    \section template_args Template Parameters
   
    \param II Iterator to Item object pointer.
    \param RI Type iterator over item responses.
    \param T  Type of latent variable.
   */
  template <class II, class RI, class T =Real> class ThetaLogLikelihood
  {

public:

    //! Constructor - Assigns values of data members.
    ThetaLogLikelihood(II begini, II endi, RI beginr, bool neg = false)
    {
      mBeginItems = begini;
      mEndItems = endi;
      mBeginResp = beginr;
      mNeg = neg;
    }

    /*!
      \brief
      Overloads function operator to return loglikelihood for a particular value of theta.

      \section template_args Template Parameters
   
      \param T  Type of latent variable.
      
      \section function_args Function Parameters
            
      \param[in]  &theta  Address of ability parameter theta.
     */
    Real operator()(const T &theta) const;

    /*!
      \brief
      Assigns item responses to compute likelihood over.
      
      \section template_args Template Parameters
   
      \param RI Type iterator over item responses.

      \section function_args Function Parameters
      
      \param[in] resp Iterator pointing to first item response of each item in
          mBeginItems to mEndItems range.
     */
    void SetResponses(RI resp)
    {
      mBeginResp = resp;
    }

private:

    //! Iterator pointing to first item response of each item in mBeginItems to mEndItems range.
    RI mBeginResp;
    
    //! Iterator to pointer to first item for likelihood computation. 
    II mBeginItems;
    
    //! Iterator to pointer to one past last item for likelihood computation. 
    II mEndItems;

    /*!
      \brief
      Flag: If true return the negative of the log likelihood.
      
      This allows the use of minimization routines rather than maximization routines 
      for computing maximum likelihood estimates.
     */
    bool mNeg;
  };

  template <class II, class RI, class T> Real ThetaLogLikelihood<II, RI, T>::operator()(const T &theta) const
  {
    Real loglikelihood = 0.0;

    for (II ii = mBeginItems; ii != mEndItems; ++ii)
    {
      RI ir = mBeginResp + (*ii)->Index();
      if (*ir != (*ii)->NotPresentedResponse())
      {
        loglikelihood += std::log((*ii)->ProbResp(*ir, theta));
      }
    }

    // return negative of loglikelihood to allow use of
    // minimization routine rather than maximization routine
    return (mNeg ? -loglikelihood : loglikelihood);
  }

} // namespace etirm

#endif // ETIRM_THETALOGLIKELIHOOD_H_
