/*! \file etirmtypes.h
 
  \brief Defines data types used by etirm.
 
  Data types representing floating point numbers, vectors and
  matrices of floating point numbers, and examinee item responses.
 
  Some types are used from the Simple C++ Numerical Toolkit (SCPPNT).
  SCPPNT is available from http://www.smallwaters.com/software/cpp/scppnt.html.

  Estimation Toolkit for Item Response Models (ETIRM)
  http://www.smallwaters.com/software/cpp/etirm.html

  Author(s): 
  Werner Wothke, maintenance (http://www.smallwaters.com)
  Brad Hanson (http://www.b-a-h.com/)
  See the file LICENSE for information on usage and redistribution.

  Copyright (C) 2008, Werner Wothke
  Copyright (c) 2000-2002, Bradley A. Hanson
 */

#ifndef ETIRMTYPES_H_
#define ETIRMTYPES_H_

#ifndef ETIRM_FLOAT_TYPE
/*!
  \brief
  This definition describes the default data type used for floating point 
  numbers. \
  
  It defaults to double, but can be overriden at compile time redefining 
  ETIRM_FLOAT_TYPE, e.g.

  g++ -DETIRM_FLOAT_TYPE='float'  ...
 */
#define ETIRM_FLOAT_TYPE double
#endif

#ifndef ETIRM_RESPONSE_TYPE
/*!
  \brief
  This definition describes the default data type used for an item response 
  and covariant for an examinee.
   
  It defaults to char, but can be overriden at compile time redefining 
  ETIRM_RESPONSE_TYPE, e.g.
 
  g++ -DETIRM_RESPONSE_TYPE='int'  ...
 */
#define ETIRM_RESPONSE_TYPE char
#endif

#ifdef ETIRM_USE_BOOST_CONFIG
// Use configuration file from the Boost libraries
// (http://www.boost.org) to set the macros
// used by ETIRM that begin with BOOST_
// for the particular compiler being used.
#include <boost/config.hpp>
#endif

#ifdef SCPPNT_NO_DIR_PREFIX
#include "scppnt_error.h" // exception classes from Simple C++ Numerical Toolkit (SCPPNT)
#include "vec.h" // vector class from Simple C++ Numerical Toolkit (SCPPNT)
#include "cmat.h" // matrix class from Simple C++ Numerical Toolkit (SCPPNT)
#else
#include "scppnt/scppnt_error.h" // exception classes from  Simple C++ Numerical Toolkit (SCPPNT)
#include "scppnt/vec.h" // vector class from Simple C++ Numerical Toolkit (SCPPNT)
#include "scppnt/cmat.h" // matrix class from Simple C++ Numerical Toolkit (SCPPNT)
#endif

namespace etirm
{
  /*!
   \brief
   Data type for floating point numbers.

   This type is defined globally rather than
   being a template parameter in individual classes
   because it seemed unlikely that one would want
   different floating point types used for different
   ETIRM classes.
   */
  typedef ETIRM_FLOAT_TYPE Real;

  //! Data type to hold an examinee item response
  typedef ETIRM_RESPONSE_TYPE Response;

  /*! 
    \brief 
    Vector type containing floating point numbers. Used in numeric calculations.
   */
  typedef SCPPNT::Vector<Real> RealVector;
  
  
  /*! 
    \brief
    Matrix type containing floating point numbers. Used in numeric calculations.
   */
  typedef SCPPNT::Matrix<Real> RealMatrix;

  //! Using SCPPNT exception types for logical errors.
  typedef SCPPNT::LogicError LogicError;
  
  //! Using SCPPNT exception types for invalid arguments. 
  typedef SCPPNT::InvalidArgument InvalidArgument;
  
  //!  Using SCPPNT exception types for runtime errors. 
  typedef SCPPNT::RuntimeError RuntimeError;
  
  //!  Using SCPPNT exception types for exception violations. 
  typedef SCPPNT::Exception Exception;

  //! Enumeration for type of IRT model
  enum IRTModel
  {
    //! One-parameter logistic for dichotomous items.
    OnePL,
    //! Two-parameter logistic for dichotomous items.
    TwoPL,
    //! Three-parameter logistic for dichotomous items.
    ThreePL,
    //! Partial credit model for polytomous items
    PCM,
    //! Generalized partial credit model for polytomous items
    GPCM
  };

}

#undef ETIRM_FLOAT_TYPE
#undef ETIRM_RESPONSE_TYPE

#endif // ETIRMTYPES_H_
