/*! \file ItemParamPriorNormal.h
 
  \brief
  Class derived from ItemParamPrior representing a normal prior distribution
  of item parameters for use in Bayes modal estimation.
 
  mParameter[0] = mean of normal distribution
  mParameter[1] = standard deviation of normal distribution.

  Note the second parameter is the standard deviation, NOT the variance.

  Estimation Toolkit for Item Response Models (ETIRM)
  http://www.smallwaters.com/software/cpp/etirm.html

  Author(s): 
  Werner Wothke, maintenance (http://www.smallwaters.com)
  Brad Hanson (http://www.b-a-h.com/)
  See the file LICENSE for information on usage and redistribution.

  Copyright (C) 2008, Werner Wothke
  Copyright (c) 2000-2001, Bradley A. Hanson
 */

#ifndef ETIRM_ITEMPARAMPRIORNORMAL_H_
#define ETIRM_ITEMPARAMPRIORNORMAL_H_

#ifdef ETIRM_NO_DIR_PREFIX
#include "ItemParamPrior.h"
#else
#include "etirm/ItemParamPrior.h"
#endif

namespace etirm
{
  /*!
    \brief
    Class derived from ItemParamPrior representing a normal prior distribution
    of item parameters for use in Bayes modal estimation.
   */
  class ItemParamPriorNormal : public ItemParamPrior
  {
public:

    ItemParamPriorNormal();
    ItemParamPriorNormal(RealVector &param);
    ItemParamPriorNormal(Real mean, Real sd);
    
    //! Returns number of prior Normal distribution parameters for the IRT item.
    virtual int NumParameters()
    {
      return 2;
    }

    virtual Real LogDensity(Real p);
    // Returns log of the density function.

    virtual Real DerivLogDensity1(Real p);
    // Returns the first derivative of the log density

    virtual Real DerivLogDensity2(Real p);
    // Returns the second derivative of the log density

    virtual std::string DistributionName() const
    {
      return std::string("normal");
    }
    //!< Returns string containing name of distribution used for prior.


private:

    Real variance;
    //!< Variance of Normal distribution.
  };

} // namespace etirm

#endif // ETIRM_ITEMPARAMPRIORNORMAL_H_
 
