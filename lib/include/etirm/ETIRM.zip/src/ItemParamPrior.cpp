/*! \file ItemParamPrior.cpp
 
  \brief
  Class representing a prior distribution used for item parameters
  in Bayes modal estimation.
 
  Estimation Toolkit for Item Response Models (ETIRM)
  http://www.smallwaters.com/software/cpp/etirm.html 

  Author(s): 
  Werner Wothke, maintenance (http://www.smallwaters.com)
  Brad Hanson (http://www.b-a-h.com/)
  See the file LICENSE for information on usage and redistribution.

  Copyright (C) 2008, Werner Wothke
  Copyright (c) 2000-2001, Bradley A. Hanson
 */

#ifdef ETIRM_NO_DIR_PREFIX
#include "ItemParamPrior.h"
#else
#include "etirm/ItemParamPrior.h"
#endif

namespace etirm
{

  /* Constructor initializing parameter vector */
  ItemParamPrior::ItemParamPrior(RealVector &param) :
    mParameters(param)
  {
  }

  /* Constructor initializing size of parameter vector, but not parameter values */
  ItemParamPrior::ItemParamPrior(int numparam) :
    mParameters(numparam)
  {
  }

  /* Destructor */
  ItemParamPrior::~ItemParamPrior()
  {
  }

  /* Set parameters of density */
  void ItemParamPrior::SetParameters(RealVector &param)
  {
    if (param.size() != NumParameters())  // Changed "==" to "!=" (ww, 2-22-2008)
      throw InvalidArgument("Invalid number of parameters in prior distribution",
          "ItemParamPrior::SetParameters");

    mParameters = param;
  }

  /* Get parameters of density */
  RealVector ItemParamPrior::GetParameters()
  {
    return RealVector(mParameters);
  }

} // namespace etirem
