/*! \file ItemParamPriorBeta4.cpp
 
  \brief
  Class representing a four-parameter beta prior distribution of item parameters
  in Bayes modal estimation.
 
  mParameter[0] = a shape parameter
  mParameter[1] = b shape parameter
  mParameter[2] = lower limit of distribution
  mParameter[3] = upper limit of distribution

  Estimation Toolkit for Item Response Models (ETIRM)
  http://www.smallwaters.com/software/cpp/etirm.html

  Author(s): 
  Werner Wothke, maintenance (http://www.smallwaters.com)
  Brad Hanson (http://www.b-a-h.com/)
  See the file LICENSE for information on usage and redistribution.

  Copyright (C) 2008, Werner Wothke
  Copyright (c) 2000-2001, Bradley A. Hanson
 */

#ifdef ETIRM_NO_DIR_PREFIX
#include "ItemParamPriorBeta4.h"
#else
#include "etirm/ItemParamPriorBeta4.h"
#endif

#include <cmath> // for log
// for compilers which do not put C library functions in std namespace
#ifdef BOOST_NO_STDC_NAMESPACE
namespace std
{ using ::log;}
#endif

namespace etirm
{

  /*!
    \brief
    Class construction from a parameter vector.
   */
  ItemParamPriorBeta4::ItemParamPriorBeta4(RealVector &param) :
    ItemParamPrior(param)
  {
  }

  /*!
    \brief
    Class construction from four individual parameter values.
   */
  ItemParamPriorBeta4::ItemParamPriorBeta4(Real a, Real b, Real l, Real u) :
    ItemParamPrior(4)
  {
    // check for valid parameters
    if (a <= 0.0 || b <= 0.0)
      throw RuntimeError("Invalid shape parameter for beta dist",
          "ItemParamPriorBeta4::ItemParamPriorBeta4");
    if (l >= u)
      throw RuntimeError("Invalid upper or lower limit for beta dist",
          "ItemParamPriorBeta4::ItemParamPriorBeta4");

    mParameters[0] = a;
    mParameters[1] = b;
    mParameters[2] = l;
    mParameters[3] = u;
  }

  /*!
    \brief
    Default constructor - assign uniform [0,1] distribution 
   */
  ItemParamPriorBeta4::ItemParamPriorBeta4() :
    ItemParamPrior(4)
  {

    mParameters[0] = 1.0;
    mParameters[1] = 1.0;
    mParameters[2] = 0.0;
    mParameters[3] = 1.0;
  }

  // If the density of x is zero then return the point nearest x that 
  // has a non-zero density.
  Real ItemParamPriorBeta4::NearestNonZero(Real x)
  {
    // Density at lower and upper limits has zero
    // density, so return a value that is offset
    // from the lower and upper limits by the following amount
    const Real offset = 0.001;

    if (x <= mParameters[2])
    {
      return mParameters[2]+offset;
    }
    else if (x >= mParameters[3])
    {
      return mParameters[3]-offset;
    }
    else
    {
      return x;
    }
  }

  /*!
    \brief
    Only computes part of the log of the density that depends on the parameter.
   
    \param[in]  p  Argument of log density function (an item parameter value)
   */
  Real ItemParamPriorBeta4::LogDensity(Real p)
  {

    /* Check for value outside limits of distribution */
    if (ItemParamPriorBeta4::ZeroDensity(p))
    {
      {
        return std::log(0.0);
      }
    }

    Real value = (mParameters[0] - 1.0) * std::log(p - mParameters[2]);

    value += (mParameters[1] - 1.0) * std::log(mParameters[3] - p);

    return value;
  }

  /*!
    \brief
    First derivative of log density.

    Only computes part of the log of the density that depends on the parameter
   */
  Real ItemParamPriorBeta4::DerivLogDensity1(Real p)
  {
    /* Outside limits of distribution density does not change,
     so derivative is zero */
    if (ItemParamPriorBeta4::ZeroDensity(p))
      return 0.0;

    Real value = (mParameters[0] - 1.0) / (p - mParameters[2]);
    value -= (mParameters[1] - 1.0) / (mParameters[3] - p);

    return value;
  }

  /*!
    \brief
     Second derivative of log density.

     Only computes part of the log of the density that depends on the parameter.
   */
  Real ItemParamPriorBeta4::DerivLogDensity2(Real p)
  {
    /* Outside limits of distribution density does not change,
     so derivative is zero */
    if (ItemParamPriorBeta4::ZeroDensity(p))
      return 0.0;

    Real denom = p - mParameters[2];
    Real value = (1.0 - mParameters[0]);
    value /= denom*denom;
    denom = mParameters[3] - p;
    value -= (mParameters[1] - 1.0) / (denom*denom);

    return value;
  }

} // namespace etirm
