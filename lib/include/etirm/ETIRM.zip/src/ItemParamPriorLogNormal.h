/*! \file ItemParamPriorLogNormal.h
 
  \brief 
  Class derived from ItemParamPrior representing a lognormal prior distribution
  of item parameters for use in Bayes modal estimation.
 
  \param  mParameter[0]  mean parameter of lognormal distribution
  \param  mParameter[1]  standard deviation parameter of lognormal distribution.

  Note the second parameter is the standard deviation, NOT the variance.

  Estimation Toolkit for Item Response Models (ETIRM)
  http://www.smallwaters.com/software/cpp/etirm.html

  Author(s): 
  Werner Wothke, maintenance (http://www.smallwaters.com)
  Brad Hanson (http://www.b-a-h.com/)
  See the file LICENSE for information on usage and redistribution.

  Copyright (C) 2008, Werner Wothke
  Copyright (c) 2000-2001, Bradley A. Hanson
 */

#ifndef ETIRM_ITEMPARAMPRIORLOGNORMAL_H_
#define ETIRM_ITEMPARAMPRIORLOGNORMAL_H_

#ifdef ETIRM_NO_DIR_PREFIX
#include "ItemParamPrior.h"
#else
#include "etirm/ItemParamPrior.h"
#endif

namespace etirm
{
  /*!   
    \brief 
    Class derived from ItemParamPrior representing a lognormal prior distribution
    of item parameters for use in Bayes modal estimation.
   */
  class ItemParamPriorLogNormal : public ItemParamPrior
  {
public:

    ItemParamPriorLogNormal();
    ItemParamPriorLogNormal(RealVector &param);
    ItemParamPriorLogNormal(Real mean, Real sd);

    //! Returns number of prior logNormal distribution parameters for the IRT parameter.
    virtual int NumParameters()
    {
      return 2;
    }

    virtual bool ZeroDensity(Real p)
    {
      return (p <= 0.0) ? true : false;
    }
    //!< Returns true if density at p is zero.

    /*!
      \brief
      If density of x is zero (x <= 0) then this function returns a small value 
      slightly greater than zero that has a non-zero density.
     */
    virtual Real NearestNonZero(Real x)
    {
      return (x <= 0.0) ? 0.001 : x;
    }

    virtual Real LogDensity(Real p);
    // Returns log of the density function.

    virtual Real DerivLogDensity1(Real p);
    // Returns the first derivative of the log density

    virtual Real DerivLogDensity2(Real p);
    // Returns the second derivative of the log density

    virtual std::string DistributionName() const
    {
      return std::string("lognormal");
    }
    //!< Returns string containing name of distribution used for prior.


private:

    Real variance;
    //!< Variance of log-Normal distribution.
  };

} // namespace etirm

#endif // ETIRM_ITEMPARAMPRIORLOGNORMAL_H_
