/*! \file ICRF_PCM.h
 
  \brief
  Class for computing item category response function (ICRF) 
  and its derivative for the partial credit model.

  Estimation Toolkit for Item Response Models (ETIRM)
  http://www.smallwaters.com/software/cpp/etirm.html

  Author(s): 
  Werner Wothke, maintenance (http://www.smallwaters.com)
  Brad Hanson (http://www.b-a-h.com/)
  See the file LICENSE for information on usage and redistribution.

  Copyright (C) 2008, Werner Wothke
  Copyright (c) 2000-2002, Bradley A. Hanson
 */

#ifndef ETIRM_ICRF_PCM_H_
#define ETIRM_ICRF_PCM_H_

#ifdef ETIRM_NO_DIR_PREFIX
#include "etirmtypes.h"
#else
#include "etirm/etirmtypes.h"
#endif

#include <string>

namespace etirm
{
  /*! \brief Class for Masters' PCM item response function.
   */
  class ICRF_PCM
  {

public:

    /*! Class Constructor */
    ICRF_PCM(int ncat, Response firstResp, Real a = 1.0) :
      mNumCat(ncat), mNumParameters(ncat-1), mFirstResponse(firstResp), mExpz(ncat), mA(a)
    {
    }

    Real ICRF(Response r, const RealVector &param, Real theta) const;
    /*!< Returns value of item characteristic response function (ICRF)
         for response r, parameters in vector param (b1, b2, ...),
         and theta value.
     */

    Real OpenICRF(Response r, const RealVector &param, Real theta) const;
    //!< Returns value of ICRF in open interval (0,1)

    void ICRFDeriv1(Response r, const RealVector &param, Real theta, RealVector &deriv);
    //!< Computes value of first derivative of ICRF (gradient)

    bool GradientDefined() const
    {
      return true;
    }
    //!< Function indicating that gradient (ICCDeriv1) is defined.

    bool HessianDefined() const
    {
      return false;
    }
    //!< Function indicating that Hessian is not defined.

    void Scale(Real slope, Real intercept, RealVector &param);
    //!< Compute linear transformation of item parameters onto a new IRT scale

    int NumParameters() const
    {
      return mNumParameters;
    }
    //!< Returns number of estimated parameters

    int NumAllParameters() const
    {
      return mNumParameters+1;
    }
    //!< Returns number of fixed (a) and estimated (b1, b2, ...) parameters.

    int NumRespCat() const
    {
      return mNumCat;
    }
    //!< Returns number of response categories

    std::string Name() const
    {
      return std::string("PCM");
    }
    //!< Return name of model

    IRTModel Model() const
    {
      return PCM;
    }
    //!< Return model type from enum defined in etirmtypes.h

    void GetAllParameters(const RealVector &estParam, RealVector &allParam) const;
    /*!< Copy fixed a parameter and estimated b parameters from estParam into allParam.
         Set a, b1, b2, ... parameters, where a is fixed, and
         b1, b2, ... are estimated.
      */
    
    //! Set a, b1, b2, ... parameters
    template <class I> void SetAllParameters(I begin_param, I end_param, RealVector &estParam)
    {

      if ((end_param - begin_param) != (mNumParameters+1) || estParam.size() != mNumParameters)
        throw InvalidArgument("Wrong number of parameters", "ICRF_PCM::SetAllParameters");

      mA = *begin_param++;
      RealVector::iterator ie = estParam.begin();
      while (begin_param != end_param)
      {
        *ie = *begin_param;
        ++ie;
        ++begin_param;
      }
    }

private:

    int mNumCat; //!< number of response categories

    int mNumParameters; //!< number of estimated parameters in model

    Real mA;
    //!< slope parameter

    Response mFirstResponse;
    //!< Response associated with first response category

    RealVector mExpz;
    /*!< Holds the terms exp(sum_{k=1}^i z_k), i = 1, mNumCat-1, where
         z_k = a * (theta - b_k), a = param[0], b_k = param[k]. Used
         in computing the derivative of the ICRF.
     */

    Real mDenom; //!< denominator of ICRF

    Real mDenom2; //!< Square of mDenom

    void ExpZ(const RealVector &param, Real theta);
    //!< Computes mDenom, mDenom2, and elements of mExpz.

  };

} // namespace etirm

#endif // ETIRM_ICRF_GPCM_H_
