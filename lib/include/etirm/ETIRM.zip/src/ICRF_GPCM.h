/*! \file ICRF_GPCM.h
 
  \brief
  Class for computing item category response function (ICRF) 
  and its derivative for the generalized partial credit model.

  Estimation Toolkit for Item Response Models (ETIRM)
  http://www.smallwaters.com/software/cpp/etirm.html

  Author(s): 
  Werner Wothke, maintenance (http://www.smallwaters.com)
  Brad Hanson (http://www.b-a-h.com/)
  See the file LICENSE for information on usage and redistribution.

  Copyright (C) 2008, Werner Wothke
  Copyright (c) 2000-2002, Bradley A. Hanson
 */

#ifndef ETIRM_ICRF_GPCM_H_
#define ETIRM_ICRF_GPCM_H_

#ifdef ETIRM_NO_DIR_PREFIX
#include "etirmtypes.h"
#else
#include "etirm/etirmtypes.h"
#endif

#include <string>

namespace etirm
{

  /*! \brief Class for the GPCM item response function.
   */
  class ICRF_GPCM
  {

public:

    /*! Class Constructor */
    ICRF_GPCM(int ncat, Response firstResp) :
      mNumCat(ncat), mNumParameters(ncat), mFirstResponse(firstResp), mExpz(ncat)
    {
    }

    Real ICRF(Response r, const RealVector &param, Real theta) const;
    /*!< Return value of item characteristic response function (ICRF)
         for response r, parameters in vector param (a, b1, b2, ...),
         and theta value.
     */

    Real OpenICRF(Response r, const RealVector &param, Real theta) const;
    //!< Return value of ICRF in open interval (0,1)

    void ICRFDeriv1(Response r, const RealVector &param, Real theta, RealVector &deriv);
    //!< Compute value of first derivative of ICRF (gradient)

    bool GradientDefined() const
    {
      return true;
    }
    //!< Function that computes gradient (ICCDeriv1) is defined.

    bool HessianDefined() const
    {
      return false;
    }
    //!< Function that computes hessian is not defined.

    void Scale(Real slope, Real intercept, RealVector &param);
    //!< Linearly transform item parameters to new IRT scale

    int NumParameters() const
    {
      return mNumParameters;
    }
    //!< Return number of estimated parameters.

    int NumAllParameters() const
    {
      return mNumParameters;
    }
    /*!< Return number of fixed and estimated parameters.
     In this case there are no fixed parameters.
     */

    int NumRespCat() const
    {
      return mNumCat;
    }
    //!< Return number of response categories

    std::string Name() const
    {
      return std::string("GPCM");
    }
    //!< Return name of model

    IRTModel Model() const
    {
      return GPCM;
    }
    //!< Return model type from enum defined in etirmtypes.h

    void GetAllParameters(const RealVector &estParam, RealVector &allParam) const;
    //!< Copy a, b1, b2, ... parameters from estParam into allParam.

    //! Set a, b1, b2, ... parameters
    template <class I> void SetAllParameters(I begin_param, I end_param, RealVector &estParam)
    {

      if ((end_param - begin_param) != mNumParameters || estParam.size() != mNumParameters)
        throw InvalidArgument("Wrong number of parameters", "ICRF_GPCM::SetAllParameters");

      RealVector::iterator ie = estParam.begin();
      while (begin_param != end_param)
      {
        *ie = *begin_param;
        ++ie;
        ++begin_param;
      }
    }

private:

    int mNumCat; //!< number of response categories

    int mNumParameters; //!< number of parameters in model

    Response mFirstResponse; //!< response corresponding to the first response category

    RealVector mExpz;
    /*!< Holds the terms exp(sum_{k=1}^i z_k), i = 1, mNumCat-1, where
     z_k = a * (theta - b_k), a = param[0], b_k = param[k]. Used
     in computing the derivative of the ICRF.
     */

    Real mDenom; //!< denominator of ICRF

    Real mDenom2; //!< Square of mDenom

    void ExpZ(const RealVector &param, Real theta);
    //!< Computes mDenom, mDenom2, and elements of mExpz.

  };

} // namespace etirm

#endif // ETIRM_ICRF_GPCM_H_
