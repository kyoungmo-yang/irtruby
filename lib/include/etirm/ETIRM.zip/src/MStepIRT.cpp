/*! \file MStepIRT.cpp
 
  \brief
	Functions useful in implementing the M-step for IRT models. 

	Estimation Toolkit for Item Response Models (ETIRM)
	http://www.smallwaters.com/software/cpp/etirm.html

  Author(s): 
  Werner Wothke, maintenance (http://www.smallwaters.com)
  Brad Hanson (http://www.b-a-h.com/)
  See the file LICENSE for information on usage and redistribution.

  Copyright (C) 2008, Werner Wothke
	Copyright (c) 2000-2001, Bradley A. Hanson
*/

#ifdef ETIRM_NO_DIR_PREFIX
#include "MStepIRT.h"
#else
#include "etirm/MStepIRT.h"
#endif

namespace etirm
{

/*
  Returns the maximum relative difference between an old and new set of item parameters.
  
  \param[in] &oldParam  Address of vector containing base parameter values.
  \param[in] &newParam  Address of vector containing comparison (new) parameter values.
  \param[in] typicalValue Minimum denominator for relative comparison.
*/
double MaxRelParamDiff(RealVector &oldParam, RealVector &newParam, Real typicalValue)
{
	double reldiff = 0.0;
	
	RealVector::iterator iold = oldParam.begin();
	RealVector::iterator inew = newParam.begin();
	
	for (int n = oldParam.size(); n--; ++iold, ++inew)
	{
		Real d = *iold - *inew;
		Real denom = *inew;
		denom = (denom < 0.0) ? -denom : denom; // fabs(denom)
		denom = (denom < typicalValue) ? typicalValue : denom;
		if (denom != 0.0) d /= denom;
		d = (d < 0.0) ? -d : d; // fabs(d)
		if (reldiff < d) reldiff = d;
	}
	
	return reldiff;
}

} // namespace etirm
