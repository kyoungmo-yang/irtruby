/*! \file ItemParamPrior.h
 
  \brief
  Class representing a prior distribution used for item parameters
  in Bayes modal estimation.
  
  Estimation Toolkit for Item Response Models (ETIRM)
  http://www.smallwaters.com/software/cpp/etirm.html 

  Author(s): 
  Werner Wothke, maintenance (http://www.smallwaters.com)
  Brad Hanson (http://www.b-a-h.com/)
  See the file LICENSE for information on usage and redistribution.

  Copyright (C) 2008, Werner Wothke
  Copyright (c) 2000-2001, Bradley A. Hanson
 */

#ifndef ETIRM_ITEMPARAMPRIOR_H_
#define ETIRM_ITEMPARAMPRIOR_H_

#ifdef ETIRM_NO_DIR_PREFIX
#include "etirmtypes.h"
#else
#include "etirm/etirmtypes.h"
#endif

#include <vector> // needed for declaration of PriorVector
#include <string>

namespace etirm
{

  /*!
   \brief
   Class representing a prior distribution used for item parameters
   in Bayes modal estimation.
   */
  class ItemParamPrior
  {
public:

    /*!
     \brief
     Constructor assigning values of prior parameters from a vector.
     
     \param[in] &param Address of parameter vector for this item.
     */
    ItemParamPrior(RealVector &param);

    /*!
     \brief
     Constructor setting the number of prior parameters, but not values of the parameters.
     
     \param[in] numparam Number of parameter for this item.
     */
    explicit ItemParamPrior(int numparam);

    virtual ~ItemParamPrior();
    //!< Virtual destructor used here so that the correct destructor gets called in derived classes.

    /*!
      \brief 
      Assigns item parameter from vector.
      
      \param[in] &param Address of parameter vector for this item.
     */
    void SetParameters(RealVector &param);

    /*!
      \brief
      Returns parameter vector for this item.
     */
    RealVector GetParameters();

    /*!
      \brief
      Returns number of prior distribution parameters for the IRT parameter.
      
      Defined in derived class to return number of parameters in prior density.
     */
    virtual int NumParameters() = 0;
    
    virtual bool ZeroDensity(Real /* p */)
    {
      return false;
    }
    //!< Returns true if density at p is zero. By default the density is non-zero at all points.

    /*!
      \brief
      If x has density zero, this function returns the value
      closest to x that has a non-zero density.
      
      The Default is to assume all values of x have a non-zero density.
      
      \param[in]  x Quadrature point.
     */
    virtual Real NearestNonZero(Real x)
    {
      return x;
    }

    virtual Real LogDensity(Real p) = 0;
    //!< Returns the log of the density function.

    virtual Real DerivLogDensity1(Real p) = 0;
    //!<  Returns the first derivative of the log density.

    virtual Real DerivLogDensity2(Real p) = 0;
    //!< Returns the second derivative of the log density.

    virtual std::string DistributionName() const = 0;
    //!< Returns the string containing name of distribution used for prior.

protected:

    RealVector mParameters;
    //!< Parameters of prior distribution
  };

  /*!
    \brief
    Data type to represent a vector of pointers to prior distributions.
   */
  typedef std::vector<ItemParamPrior *> PriorVector;

} // namespace etirm

#endif // ETIRM_ITEMPARAMPRIOR_H_
