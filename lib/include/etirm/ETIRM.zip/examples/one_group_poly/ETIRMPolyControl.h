/*! \file ETIRMPolyControl.h

	\brief 
	Definition of class ETIRMPolyControl.
	ETIRMPolyControl stores information read from the control file for
	the ETIRM example program etirmpoly.cpp.
*/

// ETIRM headers
#ifdef ETIRM_NO_DIR_PREFIX
#include "ItemParamPrior.h"
#include "ItemNR.h"
#include "DiscreteLatentDist.h"
#include "ICCLogistic.h"
#include "ICRF_GPCM.h"
#include "ItemDichotomous.h"
#include "ItemPolytomous.h"
#else
#include "etirm/ItemParamPrior.h"
#include "etirm/ItemNR.h"
#include "etirm/DiscreteLatentDist.h"
#include "etirm/ICCLogistic.h"
#include "etirm/ICRF_GPCM.h"
#include "etirm/ItemDichotomous.h"
#include "etirm/ItemPolytomous.h"
#endif

// C++ standard library headers
#include <string>
#include <vector>

namespace etirm {

// Types to hold information about items modeled using the 3PL or GPCM model 
typedef ItemDichotomous<DiscreteLatentDist<Real>, ICCLogistic<3> > 
	item3PL_type;
typedef ItemPolytomous<DiscreteLatentDist<Real>, ICRF_GPCM > 
	itemGPCM_type;

// Type used for vector of items. Using ItemNR allows different items to be modeled
// by different classes descendent from ItemNR (the 3PL model could is used for
// some items, and the generalized partial credit model is used for other items).
typedef ItemNR<DiscreteLatentDist<Real> > item_type;


// Vector of item pointers
typedef std::vector<item_type *> ItemVector;

class ETIRMPolyControl
{

public:

	ETIRMPolyControl();
	~ETIRMPolyControl();
	
	void ReadControl(const char *filename, ItemVector &items);
		// Read information from control file

	int numIterations;
		// Number of iterations
	
	Real criterion;
		// Convergence criterion
	
	DiscreteLatentDist<Real> *latentDist;
		// Discrete latent variable distribution over which
		// the posterior is marginalized.
	
private:

	/* Priors for a, b, and c parameters. Same prior is used for all items */
	ItemParamPrior *priorA;
		// Prior for a-parameter of 3PL or GPCM model.
	ItemParamPrior *priorB;
		// Prior for b-parameter for 3PL or GPCM model. 
		// The same prior is used for all GPCM b-parameters.
	ItemParamPrior *priorC;
		// Prior for c-parameter of 3PL model.
	
	/* Starting values for a, b, and c parameters. Same starting value are used
	   for all items. */
	Real startA;
		// Starting value for a-parameter of 3PL or GPCM model.
	Real startB;
		// Starting value for b-parameter for 3PL or GPCM model. 
		// The same starting value is used for all GPCM b-parameters.
	Real startC;
		// Starting value for c-parameter of 3PL model.

};

} // namespace etirm
