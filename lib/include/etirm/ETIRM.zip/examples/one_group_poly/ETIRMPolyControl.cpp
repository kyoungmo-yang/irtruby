/*! \file ETIRMPolyControl.cpp

	\brief
	Definition of member functions for class ETIRMPolyControl.
	ETIRMPolyControl stores information read from the control file for
	the ETIRM example program etirmpoly.cpp.

*/

#include "ETIRMPolyControl.h"

// ETIRM headers
#ifdef ETIRM_NO_DIR_PREFIX
#include "etirmtypes.h"
#include "ItemParamPriorBeta4.h"
#include "ItemParamPriorLogNormal.h"
#include "ItemParamPriorNormal.h"
#include "DiscreteNormalDist.h"
#else
#include "etirm/etirmtypes.h"
#include "etirm/ItemParamPriorBeta4.h"
#include "etirm/ItemParamPriorLogNormal.h"
#include "etirm/ItemParamPriorNormal.h"
#include "etirm/DiscreteNormalDist.h"
#endif

// standard library headers
#include <fstream>
#include <cstdlib>
#include <vector>

using std::string;
using std::vector;

using namespace etirm;

// constructor
// Set values of priors and starting values
ETIRMPolyControl::ETIRMPolyControl() : numIterations(0), 
	criterion(0.001), 
	startA(1.0), startB(0.0), startC(0.20), latentDist(0)
{
	// Use four-parameter beta as prior for all three parameters.
	priorC = new ItemParamPriorBeta4(3.5, 4.0, 0.0, 0.5);
	priorA = new ItemParamPriorBeta4(1.75, 3.0, 0.0, 3.0);
	priorB = new ItemParamPriorBeta4(1.01, 1.01, -6.0, 6.0);
}

// destructor
// Release memory allocated in constructor
ETIRMPolyControl::~ETIRMPolyControl()
{
	if (priorA) delete priorA;
	if (priorB) delete priorB;
	if (priorC) delete priorC;
	if (latentDist) delete latentDist;
}

/*
	Read the control file.

	The control file should contain two lines.
	The first line should contain the following numbers
	separated by spaces and/or tabs:
	
	1. Number of items.
	2. Maximum number of EM iterations.
	3. Number of points to use for discrete latent variable distribution.
	4. Convergence criterion.
	
	The second line of the control file should contain a one digit
	integer for each item (NOT separated by spaces) that is either
	a '1', indicating a dichotomous item modeled using the three-parameter
	logistic model, or an integer greater than one, indicating the
	item is a polytomous item with that number of response categories
	modeled by the generalized partial credit model.
*/
void ETIRMPolyControl::ReadControl(const char *filename, ItemVector &items)
{
	std::ifstream file(filename);
	
	if (!file)
	{
		throw RuntimeError("Cannot open control file", "ReadControl");
	}

	// Read information from first line of control file
	string resp;
	int numPoints, numItems;
	file >> numItems >> numIterations >> numPoints >> criterion;
	
	if (!file)
	{
		throw RuntimeError("Bad control file format", "ReadControl");
	}
	
	// String to store second line of control file
	std::string line;

	// Read second line
	file >> line;
	
	// Check that number of characters in second line of control
	// file matches the number of items
	if (line.size() != numItems)
	{
		throw RuntimeError("Number of characters on second line of control file does not match number of items", 
			"ReadControl");
			
	}
	
	/* Use discrete approximation to standard normal  
	   on the interval [-4,4] as the latent variable distribution. */
	latentDist = new DiscreteLatentDist<Real>(numPoints, 1);
	DiscreteNormalDist(numPoints, -4.0, 4.0, latentDist->begin_points(), latentDist->begin_weights(1));
	
	// ICC for 3PL model
	ICCLogistic<3> icc(1.7);

	item_type *item;
	int index = 0;
	RealVector param(3); // vector to hold item starting values
	PriorVector priors(3); // vector to hold item prior distributions
	string::iterator pline = line.begin();

	// loop over characters in second line of control file
	for (int i=0; i<numItems; ++i, ++pline) 
	{
		int ncat = *pline - '0';
		if (ncat == 1) // 3PL
		{
			param.newsize(3);
			param[0] = startA;
			param[1] = startB;
			param[2] = startC;
			
			priors.resize(3);
			priors[0] = priorA;
			priors[1] = priorB;
			priors[2] = priorC;
			
			item = new item3PL_type(index++, icc, latentDist);
			
		}
		else if (ncat > 1) // GPCM
		{
			param.newsize(ncat);
			priors.resize(ncat);
			
			param[0] = startA;
			priors[0] = priorA;
			
			for (int j = 1; j<ncat; ++j)
			{
				priors[j] = priorB;
				
				param[j] = startB;
				
			}
			
			ICRF_GPCM icrf(ncat, item_type::DefaultFirstResponse());
			item = new itemGPCM_type(index++, icrf, latentDist);
			
		}
		else // invalid value
		{
			throw RuntimeError("Invalid number on second line of control file", "ReadControl");
		}

		item->SetParameters(param); // assign starting values for item
		item->SetPriors(priors); // assign priors for item
		items.push_back(item); // add item pointer to end of vector containing items

	}


}
