/*! \file etirmpoly.cpp

	\brief
	Example item parameter estimation program using ETIRM
	(http://www.smallwaters.com/software/cpp/etirm.html).
 */
 
/*
	Allows a mix of dichotomous items modeled by the three-parameter
	logistic model (3PL), and polytomous items modeled by the generalized
	partial credit model(GPCM). All examinees are
	assumed to come from a single population.
	
	To run the program type the name of the executable file followed by
	a control file name, the name of the file containing the input item
	responses, and the name of the file where the output will be
	written. For example:
	
		etirmpoly mondatx_poly.ctl ../simpoly/mondatx_poly.dat mondatx_poly.out
	
	where 'mondatx_poly.ctl' is the control file, '../simpoly/mondatx_poly.dat'
	is the file containing examinee item responses, and 'mondatx_poly.out'
	is the file where the program output will be written. 
	
	There should be two lines in the control file.
	The first line of the control should contain 4 numbers separated by
	white space:
	
	1. Number of items. (integer)
	2. Maximum number of EM iterations to perform. (integer)
	3. Number of points for the discrete latent variable distribution 
	   of examinee ability (integer)
	4. Convergence criterion. (real)
	
	The second line of the control file contains a list of integers representing
	the model to use for each item. A '1' indicates that the item is dichotomous
	and that the three-parameter logistic model should be used for the item. An
	integer greater than 1 indicates the item is polytomous with the number of
	response categories given by the integer. The generalized partial credit
	model will be used for polytomous items.
	
	For example, a control file for estimating parameters for 60 dichotomous
	items and 4 polytomous items each with 4 response categories (64 total items),
	allowing a maximum of 100 EM iterations, 40 points for the discrete latent
	variable distribution, and a convergence criterion of 0.001 is:
	
		64 100 40 0.001
		1111111111111111111111111111111111111111111111111111111111114444


	Item responses in the data file (the file specified by the second command
	line argument) are assumed to be at the beginning of each input record.
	Valid item responses for dichotmous items are '1' for a correct response,
	and '0' for an incorrect responses. Valid responses for polytomous items are
	0, 1, ..., ncat-1, where ncat is the number of response categories for the
	item. The maximum number of response categories for a polytomous item is 10.
	For any item a '.' indicates the examinee did not respond to the item.
	
	At the top of the output file (the file specified by the third command
	line argument) two numbers are given for each iteration:
	1) The maximum over all item parameter estimates of the relative difference
	between the estimate on this iteration and the previous iteration (this is
	used as the convergence criterion), and 2) The mode of the marginal
	posterior distribution being maximized by the EM algorithm (this should
	increase at each iteration). Following the iteration statistics are the item
	parameter estimates, one per line. Each line contains a, b, and c parameter
	estimates for the 3PL items and a and b parameters for the GPCM items. The
	number of b parameters for the GPCM items are the number of response
	categories minus 1. The parameterization used for the generalized partial
	credit model is given by Equation 11 in
	
		Muraki, E. (1992). A generalized partial credit model: Application
		of an EM algorithm. Applied Psychological Measurement, 16(2),
		159-176.
	
	To change the options used by the program (e.g., prior distributions of item
	parameters, convergence criterion, etc.) this source file and/or the source
	files ETIRMPolyControl.h and ETIRMPolyControl.cpp will need to be changed
	and the program recompiled. A Makefile is provided for recompiling the
	program using gcc under Linux.
	
	Januarey 29, 2008 (Werner Wothke)
	
	This version compiles under gcc 3.4.4 under cygwin 1.5.25 for Windows.
	In this environment, the STLport libraries are no longer required.
	

	November 1, 2001 (Brad Hanson)

	Initial version.

*/

/* 	If following symbols are defined the program should compile
	with Microsoft Visual C++ 6, although this has not been tested:
	BOOST_NO_STDC_NAMESPACE
	BOOST_MSVC6_MEMBER_TEMPLATES
	BOOST_NO_LIMITS 
	BOOST_MSVC
	SCPPNT_NO_IO

	Alternatively, if the Boost library (http://www.boost.org) is
	available the symbols ETIRM_USE_BOOST_CONFIG and SCPPNT_NO_IO
	could be defined, which in turn would appropriately define
	the other symbols begining with BOOST_ that are used by ETIRM.
*/

#ifdef BOOST_MSVC
// The following prevents numerious warnings when using Microsoft Visual C++ 6
#pragma warning( disable : 4786 ) // ident trunc to '255' chars in debug info
#endif

/* 
The header ETIRMPolyControl.h includes the following ETIRM headers:
	ItemParamPrior.h
	ItemNR.h
	DiscreteLatentDist.h
	ICCLogistic.h
	ICRF_GPCM.h
	ItemDichotomous.h
	ItemPolytomous.h

Contains definitions of types:
	item_type
	item3PL_type
	itemGPCM_type
	ItemVector
*/
#include "ETIRMPolyControl.h"


// ETIRM include files not included in ETIRMPolyControl.h.
// Unless ETIRM_NO_DIR_PREFIX is defined the directory
// containing the etirm source code must prefix the
// header file name in includes.
#ifdef ETIRM_NO_DIR_PREFIX
#include "EStepDiscrete.h"
#include "ExamineeGrpCov.h"
#include "MStepIRT.h"
#include "Start3PL.h"
#else
#include "etirm/EStepDiscrete.h"
#include "etirm/ExamineeGrpCov.h"
#include "etirm/MStepIRT.h"
#include "etirm/Start3PL.h"
#endif
// Use Uncmin class for minimization
// (http://www.smallwaters.com/software/cpp/uncmin.html)
#include "Uncmin.h"

// Standard library headers
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>
#include <cstdio>

// for compilers which do not put C library functions in std namespace
#ifdef BOOST_NO_STDC_NAMESPACE
namespace std {using ::sscanf; using ::puts; using ::abort; using ::fprintf;
using ::fputc; using ::fopen; using ::fclose; using ::fputs; using ::printf;}
#endif


using namespace etirm;


// Vector of item responses
typedef SCPPNT::Vector<Response> ResponseVector;

// Class to hold information about examinees
typedef ExamineeGrpCov<ResponseVector, RealVector> examinee_type;

/* Definitions of static data members */
template <>
Response Item<Real>::notPresentedResponse = '.';
template <>
Response Item<Real>::defaultFirstResponse = '0';

   
/* Define local functions for 
   reading file containing examinee item responses, 
   and standardizing item parameters */
namespace { // unnamed namespace for local functions


/* 
	Create examinee objects and read item responses for each examinee.
	
	Reads each item response as one character starting at the beginning of
	the record for each examinee. Valid item responses are '0', '1', ...,
	'9' (the maximum number of categories for polytomous items is
	10), and '.' indicating the examinee did not respond to the item.
   
	Returns zero if successful, nonzero if an error occurred.

	Arguments
	
	items		Vector of item object pointers for which responses will be read.
	
	examinees	Vector of pointers to examinee objects. Examinee object pointers
				will be appended to this vector.
	
	filename	Name of file containing examinee item responses.
   
*/
int ReadExamineeItemResp(ItemVector &items, std::vector<examinee_type *> &examinees, const char *filename)
{

	std::ifstream file(filename);
	
	if (!file)
	{
		std::cerr << "Cannot open item response file " << std::endl;
		return 1;
	}

	// String to store examinee record read from input file
	std::string line;

	// Read examinee records
	while (std::getline(file, line))
	{
		
		std::string::iterator responses = line.begin();
		
		examinee_type *anExaminee = new examinee_type(items.size());
		
		examinee_type::response_iterator ie = anExaminee->responses_begin();
		examinee_type::response_iterator e_end = anExaminee->responses_end();
		
		// Read item responses for one examinee
		ItemVector::iterator ii = items.begin();
		while(ie != e_end)
		{
			if (!((*ii)->CheckResponse(*responses)))
			{
				std::cerr << "Invalid item response: " << *responses << std::endl;
				return 1;
			}
			*ie = *responses++;
			++ie;
			++ii;
		}
		
		examinees.push_back(anExaminee);
	}
	
	return 0;
		
}


/* Standardize points of latent distribution so mean is zero and s.d. is one.
   Then use this transformation to standardize item parameters to be on the same scale */
void StandardizeParameters(std::vector<item_type *> &items, DiscreteLatentDist<Real> &latentDist)
{
	/* Standardize latent distribution to have mean zero and s.d. 1 */
	Real slope, intercept;
	latentDist.Scale(0.0, 1.0, 1,slope, intercept);
	
	/* Transform item parameters to be on new scale */
	std::vector<item_type *>::iterator ii = items.begin();
	for (int i = items.size(); i--; ++ii)
	{
		(**ii).ScaleParameters(slope, intercept);
	}

}
	
} // unnamed namespace

/*
	Command line arguments:
	
	1. Control file.
	2. Input file containing item responses.
	3. Output file.
	
*/
int main(int argc, char *argv[])
{

	// Class used in E-step calculation
	typedef EStepDiscrete<examinee_type, item_type, 
		std::vector<item_type *>::iterator, DiscreteLatentDist<Real> > estep_type;

	// Container to hold Uncmin optimization objects
	typedef	std::vector<Uncmin<RealVector, RealMatrix, item_type> *> UncminVector;

	const bool estLatentDist = false;
		// If true discrete latent variable distribution is estimated with item parameters
	
	int i, mFail;
	
	// check that there are three command line arguments
	// (first argument of argv array is the program name so
	// the total number of elements in argv is 4)
	if (argc != 4)
	{
		std::cerr << "Invalid number of arguments to program\n";
		return 0;
	}


	// Get input and output files from second and third command line arguments
	const char *respFile = argv[2]; // input file containing item responses
	const char *outFile = argv[3];	// output file

	// Open output file
	std::FILE *resultFile = std::fopen(outFile,"w");
	if (!resultFile)
	{
		std::cerr << "Could not open result file";
		return 0;
	}
	
	// Read control file
	ItemVector items;
	ETIRMPolyControl control;
	try
	{
		control.ReadControl(argv[1], items);
	}
	catch  (Exception &e)
	{
		std::cerr << e.what() << std::endl;
		std::fclose(resultFile);
		return 1;
	}
	int numItems = items.size(); // number of items
	
	/* Read item responses for examinees */
	std::vector<examinee_type *> examinees;
	if (ReadExamineeItemResp(items, examinees, respFile))
	{
		std::cerr << "\nError in reading item response file";
		std::fclose(resultFile);
		return 1;
	}
	

	/* Set up vector of Uncmin objects to use for optimization in M-step */
	UncminVector minProc(numItems); // Vector of minimization objects used in M-step
	UncminVector minProc3PL; // Minimization objects for just 3PL items
	ItemVector items3PL; // Just 3PL items
	for (i=0; i<numItems; ++i)
	{
		minProc[i] = new Uncmin<RealVector, RealMatrix, item_type>(items[i]->NumParameters());
		IRTModel m = items[i]->Model();
		if (m <= ThreePL && m >= OnePL)
		{
			minProc3PL.push_back(minProc[i]);
			items3PL.push_back(items[i]);
		}
	}

	/* Compute item parameter starting values for 3PL items only.
	   Parameters assigned in ETIRMPolyControl::ReadControl
	   are used as starting values for GPCM items. */
	try {
	mFail = StartingValues3PL<examinee_type::response_iterator, UncminVector::iterator,
			 std::vector<examinee_type *>::iterator, item_type, std::vector<item_type *>::iterator>
		(minProc3PL.begin(), examinees.begin(), examinees.end(), items3PL.begin(), items3PL.end(), 
			item_type::NotPresentedResponse());
	}
	catch (SCPPNT::Exception &error)
	{
		std::cerr << error.what() << std::endl;
		std::fclose(resultFile);
		return 1;
	}

	if (mFail) 
	{
		std::cout << "Failure in computing starting values\n";
		std::fputs("Failure in computing starting values\n",resultFile);
		std::fclose(resultFile);
		return 1;
	}

	/* Create E-step object */
	estep_type	estep(items.begin(), items.end(), *(control.latentDist));
	
	Real maxreldiff;
	// Compute E-step for starting values
	Real marginalLL = estep.DoEStep(examinees.begin(), examinees.end(), true, false);
	for (int iter = 1; iter <=control.numIterations; iter++)
	{
		// M-step for item parameters
		mFail = MStepItems<UncminVector::iterator, std::vector<item_type *>::iterator >
			(minProc.begin(), items.begin(), items.end(), maxreldiff, true);
			
		if (mFail)
		{
			std::cout << "M-step failed at iteration " << iter << '\n';
			/* If mFail is positive this means an error other than the maximum number of 
			   iterations being exceeded was returned by MStepItems, so iterations are stopped */
			if (mFail > 0)
			{
				std::fprintf(resultFile, "M-step failed at iteration %d for item %d: %d\n", iter, mFail,
				minProc[mFail-1]->GetMessage());
				Real gradtol, steptol;
				int iterations;
				minProc[mFail-1]->GetStoppingCriteria(gradtol, steptol, iterations);
				std::fprintf(resultFile, "Grad: %le  Step: %le  Iteration: %d\n", gradtol,
					steptol, iterations);
				break;
			}
			/* If mFail is negative this means the maximum number of iterations was exceeded
			   for one or more items. Report this, but continue iterations */
			else std::fprintf(resultFile, "Maximum number of M-step iterations exceeded for %d items\n",
				-mFail);
		}
		
		// M-step for latent variable distribution
		if (estLatentDist) 
		{
			RealVector eprob = RealVector(estep.GetNGroup(1), estep.GetNGroup(1)+estep.size());
			control.latentDist->MStep(eprob, 1);
			
			StandardizeParameters(items, *(control.latentDist));
		}
		
		// next E-step
		marginalLL = estep.DoEStep(examinees.begin(), examinees.end(), true, false);
		
		// Print convergence criterion and marginal loglikelihood for iteration
		std::fprintf(resultFile, "Iteration %03d: %.6f", iter, maxreldiff);
		std::fprintf(resultFile, "%12.4f\n", marginalLL);

		// Print convergence criterion and marginal loglikelihood for iteration to screen
		std::printf("Iteration %03d: %.6f", iter, maxreldiff);
		std::printf("%12.4f\n", marginalLL);

		if (maxreldiff < control.criterion) break; // check for convergence
	}
	std::fputc('\n', resultFile); // insert blank line in output file

	/* Print item parameter estimates */
	ItemVector::iterator ii = items.begin();
	for (i = numItems; i--; ++ii)
	{
		RealVector::iterator param = (*ii)->ParametersIterator();
		
		// write first parameter
		std::fprintf(resultFile, "%.8lf", *param);
		++param;
		
		// write remaining parameters
		for (int j = (*ii)->NumParameters()-1; j--; ++param)
		{
			std::fprintf(resultFile, "\t%.8lf", *param);
		}
		std::fputc('\n', resultFile);
	}
	
	/* Print latent variable distribution if it was estimated */
	if (estLatentDist)
	{		
		/* Write latent distribution points and weights */
		DiscreteLatentDist<Real>::point_iterator ip = control.latentDist->begin_points();
		DiscreteLatentDist<Real>::weight_iterator iw = control.latentDist->begin_weights(1);
		std::fputc('\n', resultFile);

		for (i=0; i< control.latentDist->size(); i++)
		{
			fprintf(resultFile, "%.6lf\t%.6lf\n", *ip++, *iw++);
		}
		std::fputc('\n', resultFile);
	}
	std::fclose(resultFile);

	// Release memeory
	for (i=0; i<numItems; ++i)
	{
		delete minProc[i];
		delete items[i];
	}
	std::vector<examinee_type *>::iterator ie = examinees.begin();
	for (i=examinees.size(); i--; ++ie) delete *ie;

	return 0;
}
