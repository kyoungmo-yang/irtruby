
#include <iostream>
#include <iomanip>
#include <boost/random.hpp>
#include <ctime>

using namespace boost;
using namespace std;

//double SampleNormal (double mean, double sigma)

int main()
{
  
    int NVars = 10;
    int NCases = 5000;

    // Create a Mersenne twister random number generator
    // that is seeded once with Brad's favorite seed
    static mt19937 rng(static_cast<unsigned> (7925726U));

    // Select Gaussian probability distribution
    normal_distribution<double> norm_dist(0.0, 1.0);

    // Bind random number generator to distribution, forming a function
    variate_generator<mt19937&, normal_distribution<double> >  normal_sampler(rng, norm_dist);

    // Output test data in comma-delimited format
    // a. Header line:
     
    cout.fill('0'); // Generate zero-padded integers in header line
    
    for (int j = 1; j < NVars; j++){
      cout << "NRVar" << setw(2) << j << ",";
    }
    cout << "NRVar" << setw(2) << NVars << endl;
    
    cout.fill(' '); // Reset fill character
    
    // b. Ncases records or Nvars Normal random variates each:
    
    cout.precision(8);  // Output variates at 8 significant digits
    
    for (int i = 0; i < NCases; i++){
      for (int j = 1; j < NVars; j++){
        cout << normal_sampler()<< ",";
      }
      cout << normal_sampler() << endl;
    }
    
    return 0;
}
