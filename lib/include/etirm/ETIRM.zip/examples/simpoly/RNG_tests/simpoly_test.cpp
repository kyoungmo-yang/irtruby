/*
	Example generating simulating item responses using ETIRM 
	(http://www.smallwaters.com/software/cpp/etirm.html).
	There are 60 dichtomous item responses simulated using
	the three-parameter logistic model, and 4 polytomous
	item responses, each with 4 response categories, simulated
	using the generalized partial credit model.
	The 3PL parameters were copied from ../one_group/mondatx.out.
	
	The Boost library (freely available at
	http://www.boost.org) is needed for the random
	number generators that are used.
	
	October 29, 2001 (Brad Hanson)

	Initial version.
	

*/

// Boost configuration file sets appropriate values
// of the macros beginning with BOOST_ for the compiler being used.
#include <boost/config.hpp>

#ifdef BOOST_MSVC
// The following prevents numerious warnings when using Microsoft Visual C++ 6
#pragma warning( disable : 4786 ) // ident trunc to '255' chars in debug info
#endif

// Use random number generators from Boost library
// (www.boost.org).
//#include <boost/random/mersenne_twister.hpp>
//#include <boost/random/normal_distribution.hpp>
//#include <boost/random/uniform_01.hpp>
#include <boost/random.hpp>

// ETIRM headers
#ifdef ETIRM_NO_DIR_PREFIX
#include "ItemDichotomous.h"
#include "ItemPolytomous.h"
#include "ICCLogistic.h"
#include "ICRF_GPCM.h"
#include "SimulateResponses.h"
#include "DiscreteLatentDist.h"
#else
#include "etirm/ItemDichotomous.h"
#include "etirm/ItemPolytomous.h"
#include "etirm/ICCLogistic.h"
#include "etirm/ICRF_GPCM.h"
#include "etirm/SimulateResponses.h"
#include "etirm/DiscreteLatentDist.h"
#endif

// C++ standard library headers
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>

using namespace etirm;
using std::string;

// Type to hold information about latent variable distribution
typedef DiscreteLatentDist<double> latent_dist_type;

// Type to hold information about items modeled using the 3PL or GPCM model 
typedef ItemDichotomous<latent_dist_type, ICCLogistic<3> > 
	item3PL_type;
typedef ItemPolytomous<latent_dist_type, ICRF_GPCM > 
	itemGPCM_type;

// Type used for vector of items. Using ItemNR allows different items to be modeled
// by different classes descendent from ItemNR (the 3PL model is used for
// some items, and the generalized partial credit model is used for other items).
typedef ItemNR<latent_dist_type> item_type;

// Vector of item pointers
typedef std::vector<item_type *> item_vector;

/* Definitions of static data members */
template <class T>
Response Item<T>::notPresentedResponse = '.';
template <class T>
Response Item<T>::defaultFirstResponse = '0';


// Create 3PL item objects and assign parameter estimates
// read from file.
// Returns number of items read.
int ReadParam3PL(item_vector &items, string &filename)
{
	std::ifstream file(filename.c_str());
	if (!file) return 0;
	
	RealMatrix par;
	
	file >> par;
	
	ICCLogistic<3> icc(1.7);
	for (int i = 0; i < par.num_rows(); ++i)
	{
		item3PL_type *item = new item3PL_type(i, icc, (latent_dist_type *) 0);
		item->SetParameters(par.begin_row(i+1), par.end_row(i+1));
		items.push_back(item);
	}
	
	return par.num_rows();
}

int main()
{
	string parfile("par3pl.mat"); // file containing 3PL parameters
	string basefname("ItemData"); // file containing generated item responses
	
	const int ncat = 4; // number of response categories for polytomous items
	const int nGPCM = 4; // number of polytomous items
	
	const int nobs = 2000; // number of observations to generate
	
	const boost::uint32_t u_seed = 7925726U; // seed for random number generator; edited, ww, 1/19/2008
	 
	// Generalized partial credit model parameters for 
	// polytomous items (a, b1, b2, b3).
	double gpcm_par1[ncat] = {1.0, 0.5, 0.0, 1.0};
	double gpcm_par2[ncat] = {0.75, -2.0, 0.0, 2.0};
	double gpcm_par3[ncat] = {0.5, 0.0, -0.5, -1.0};
	double gpcm_par4[ncat] = {1.5, -1.0, 0.5, 0.0};
	double *gpcm_par[nGPCM] = {gpcm_par1, gpcm_par2, gpcm_par3, gpcm_par4};
	
	// Create 3PL items
	item_vector items;
	int n3PL = ReadParam3PL(items, parfile);
	if (!n3PL) return 0;
	
	
	// Create GPCM items
	int i;
	ICRF_GPCM icrf(ncat, item_type::DefaultFirstResponse());
	for (i =0; i<nGPCM; ++i)
	{
		itemGPCM_type *item = new itemGPCM_type(n3PL+i, icrf, (latent_dist_type *) 0);
		item->SetParameters(gpcm_par[i], gpcm_par[i]+ncat);
		items.push_back(item);
	}
	
	// Create random number generators.
	// Use same base generator for normal (generating thetas) 
	// and uniform (generating item responses given theta).
//  boost::mt19937 base_rand(seed); // use Mersenne Twister as base random number generator
//	boost::normal_distribution<boost::mt19937> normal_rand(base_rand); // standard normal
//  boost::uniform_01<boost::mt19937> uniform_rand(base_rand); // uniform [0,1)

	// Mersenne twister is RNG engine:
  boost::mt19937 rng;
  
  // Initialize RN sequence:
  rng.seed(u_seed);
  
  // Select standard Normal probability distribution:
  boost::normal_distribution<double> norm_dist(0.0, 1.0);
  
  // Bind random number generator to distribution, forming a function
  boost::variate_generator<boost::mt19937&, boost::normal_distribution<double> >  
    normal_sampler(rng, norm_dist);
  
  // Define uniform (0,1) RNG, using Mersenne twister from same engine
	boost::uniform_01<boost::mt19937> uniform_rand(rng);
	

	
	// Generate item responses
	string resp(" ", items.size());

	// Generate three item response files, with theta = -1, 0, 1, respectively.
	for (int itheta = -1; itheta < 2; itheta++)
	{
	  string string_number;
	  std::stringstream iostream;
	  iostream << itheta;
	  iostream >> string_number;
	  string respfile = basefname + string_number + ".csv";
	  // Diagnostic...
	  std::cout << "Output file: " << respfile << std::endl;
	  
	  // Open file containing generated item responses
	  std::ofstream sfile(respfile.c_str()); // Added "std::" keyword. ww, 1/15/2008.
	  if (!sfile) return 0;
	  
	      // Simulate examinee theta
    double theta = (double) itheta;	  

    //  Write header line:
     
    sfile.fill('0'); // Generate zero-padded integers in header line
	  
    for (uint iitem = 0; iitem < items.size(); iitem++)
    {
      if (iitem < 9) 
        sfile << "Item" << sfile.width(2) << iitem+1 << ",";
      else
        sfile << "Item" << iitem+1 << ",";
    }
    sfile << "Theta" << std::endl;
    
    sfile.fill(' ');
    
  	for (i = 0; i < nobs; ++i)
  	{
  		// Simulate item responses
  		SimulateResponses(items.begin(), items.end(), theta, uniform_rand, resp.begin());
  		
  		// Write item responses and theta to file
  		
  		for (string::iterator ri = resp.begin(); ri != resp.end(); ri++)
  		{
  		  sfile << *ri << ",";
  		}
  		sfile << theta << std::endl;
  	}
  	
  	// Close output file
  	sfile.close();
  	
	}
	// release memory used for item objects
	item_vector::iterator ii = items.begin();
	for (i = items.size(); i--; ++ii)
	{
		delete *ii;
	}

	return 0;
}
