/*! \file etirmtwo.cpp

	\brief 
	Example three-parameter logistic item parameter estimation program using ETIRM 
	(http://www.smallwaters.com/software/cpp/etirm.html) where there are two groups of
	examinees that are assumed to come from separate populations.
 */
 
/*	
	A discrete approximation to a normal distribution is used for each
	group. On each M-step the mean and standard deviation of the latent
	variable distribution for group 2 is estimated and the points of the
	discrete latent variable distribution for group 2 are modified so
	the mean and standard are equal to these estimated values. This
	modified distribution is used for the next E-step. Thus, discrete
	approximations to a normal distribution are used for each group. For
	group 1 the mean and standard deviation are fixed at zero and one,
	and for group 2 the mean and standard deviation are estimated.

	To run the program type the name of the executable file followed by
	the number of items, the name of the file containing the input item
	responses, and the name of the file where the output will be
	written. For example, if the executable file is named 'etirm3pl2',
	there are 60 items, the input file name is 'mondat.dat' and the
	output file name is 'test3pl2.out' the following command would be used
	to run the program:
	
		etirm3pl2 60 mondat.dat test3pl2.out
	
	The first column of each record is assumed to be a '1' or '2'
	representing the group the examinee belongs to. Item responses are
	assumed to immediately follow beginning in column two. Valid item
	responses are '1' for a correct response, '0' for an incorrect
	responses, and '.' indicating the examinee did not respond to the
	item.
	
	At the top of the output file two numbers are given for each iteration:
	1) The maximum over all item parameter estimates of the relative difference
	between the estimate on this iteration and the previous iteration (this is
	used as the convergence criterion), and 2) The mode of the marginal
	posterior distribution being maximized by the EM algorithm (this should
	increase at each iteration). Separated by a blank line from the iteration
	statistics are the item parameter estimates, one per line. Each line
	contains a, b, and c parameter estimates, respectively, for an item. After
	the item parameter estimates there is a blank line followed by the discrete
	latent variable distributions for groups 1 and 2. Each line contains two
	numbers: 1) points of the discrete latent variable distributions, and 2)
	weights of the latent variable distributions. The latent variable
	distribution for group 1 is followed by the latent variable distribution for
	group 2. The distributions have the same weights, but the points differ.
	
	To change the options used by the program (e.g., prior distributions of item
	parameters, convergence criterion, etc.) this source file will need to
	be changed and the program recompiled. Makefiles are included for
	recompiling the program using the Borland 5.5 compiler under Windows 95/NT
	(Makefile.win), and gcc under Linux (Makefile).
	
	January 30, 2008 (Werner Wothke)
	
	Compiled and tested with gcc 3.4.4/cygwin 1.5.25; 
	the stlport libraries are no longer needed.


	November 3, 2001 (Brad Hanson)
	
	Modified to compile using the current version of ETIRM.
	
	
	April 28, 2001 (Brad Hanson)

	Changes to allow program to compile using Microsoft
	Visual C++ 6, and to be consistent with the latest release
	of ETIRM.
	
	The STLport C++ standard library (http://www.stlport.org/)
	is now needed when compiling with gcc 2.95.2.


	August 12, 2000 (Brad Hanson)
	
	Added print statement to print iteration information to screen.
	
	Modified to be consistent with latest version of ETIRM.
	
	
	July 16, 2000 (Brad Hanson)
	
	Fixed bug in which priors used for starting values were also used
	for EM iterations.


*/

/* 	If following symbols are defined the program should compile
	with Microsoft Visual C++ 6, although this has not been tested:
	BOOST_NO_STDC_NAMESPACE
	BOOST_MSVC6_MEMBER_TEMPLATES
	BOOST_NO_LIMITS 
	BOOST_MSVC
	SCPPNT_NO_IO

	Alternatively, if the Boost library (http://www.boost.org) is
	available the symbols ETIRM_USE_BOOST_CONFIG and SCPPNT_NO_IO
	could be defined, which in turn would appropriately define
	the other symbols begining with BOOST_ that are used by ETIRM.
*/

#ifdef BOOST_MSVC
// The following prevents numerious warnings when using Microsoft Visual C++ 6
#pragma warning( disable : 4786 ) // ident trunc to '255' chars in debug info
#endif

// ETIRM include files.
// Unless ETIRM_NO_DIR_PREFIX is defined the directory
// containing the etirm source code must prefix the
// header file name in includes.
#ifdef ETIRM_NO_DIR_PREFIX
#include "etirmtypes.h"
#include "ItemDichotomous.h"
#include "DiscreteLatentDist.h"
#include "EStepDiscrete.h"
#include "ExamineeGrpCov.h"
#include "MStepIRT.h"
#include "ItemParamPriorBeta4.h"
#include "ItemParamPriorLogNormal.h"
#include "ItemParamPriorNormal.h"
#include "DiscreteNormalDist.h"
#include "Start3PL.h"
#include "ICCLogistic.h"
#else
#include "etirm/etirmtypes.h"
#include "etirm/ItemDichotomous.h"
#include "etirm/DiscreteLatentDist.h"
#include "etirm/EStepDiscrete.h"
#include "etirm/ExamineeGrpCov.h"
#include "etirm/MStepIRT.h"
#include "etirm/ItemParamPriorBeta4.h"
#include "etirm/ItemParamPriorLogNormal.h"
#include "etirm/ItemParamPriorNormal.h"
#include "etirm/DiscreteNormalDist.h"
#include "etirm/Start3PL.h"
#include "etirm/ICCLogistic.h"
#endif

// Use Uncmin class for minimization
// (http://www.b-a-h.com/software/cpp/uncmin.html)
#include "Uncmin.h"

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>
#include <cstdio>

// for compilers which do not put C library functions in std namespace
#ifdef BOOST_NO_STDC_NAMESPACE
namespace std {using ::sscanf; using ::puts; using ::abort; using ::fprintf;
using ::fputc; using ::fopen; using ::fclose; using ::fputs; using ::printf;}
#endif

using namespace etirm;


// Vector of item responses
typedef SCPPNT::Vector<Response> ResponseVector;

// Class to hold information about examinees
typedef ExamineeGrpCov<ResponseVector, RealVector> examinee_type;

// Class to hold information about items modeled using the 3PL model
typedef ItemDichotomous<DiscreteLatentDist<double>, ICCLogistic<3> > item3PL_type;

// Type used for array of items. Using ItemNR allows different items to be modeled
// by different classes descendent from ItemNR (e.g., 3PL model could be used for
// some items, and 2PL model used for other items).
typedef ItemNR<DiscreteLatentDist<double> > item_type;

// Class used in E-step calculation
typedef EStepDiscrete<examinee_type,
	item_type, std::vector<item_type *>::iterator,DiscreteLatentDist<double> > estep_type;


/* Definitions of static data members */
template <>
Response Item<Real>::notPresentedResponse = '.';
template <>
Response Item<Real>::defaultFirstResponse = '0';

   
/* Define local functions for reading data and standardizing item parameters 
   in unnamed namespace */
namespace {


/* 
	Assumes first character of each record is group ('1' or '2'), followed
	by item responses. An '.' indicates the examinee did not respond to
	the item.

	Argument numitems gives the number of items to read for each examinee. 
   
	This function would need to be changed to read item responses in a
	different format. 
*/
int ReadExamineeItemResp(int numitems, std::vector<examinee_type *> &examinees, const char *filename)
{

	std::ifstream file(filename);
	
	if (!file)
	{
		std::cerr << "Cannot open item response file " << '\n';
		return 1;
	}

	// String to store examinee record read from input file
	std::string line;

	// Read examinee records
	while (std::getline(file, line))
	{
		
		std::string::iterator responses = line.begin();
		
		if (*responses != '1' && *responses != '2')
		{
			std::cerr << "Invalid group: " << *responses << '\n';
			return 1;
		}
		
		examinee_type *anExaminee = new examinee_type(numitems, *responses++ - '0');
		
		examinee_type::response_iterator ie = anExaminee->responses_begin();
		examinee_type::response_iterator e_end = anExaminee->responses_end();
		
		while(ie != e_end)
		{
			if (*responses != '0' && *responses != '1' && *responses != Item<Real>::NotPresentedResponse())
			{
				std::cerr << "Invalid item response: " << *responses << '\n';
				return 1;
			}
			*ie = *responses++;
			++ie;
		}
		
		examinees.push_back(anExaminee);
	}
	
	return 0;
		
}

/*
	Create discrete latent variable distribution for two groups,
	where the weights are the same for both groups, but the points
	are allowed to differ. Initially the points and weights
	are the same for both groups.
*/
DiscreteLatentDist<double> LatentDistTwo(const int npoints)
{
	
	const int ngroups = 2;
	
	DiscreteLatentDist<Real> dist(npoints, ngroups, true);
	SCPPNT::Vector<Real> weights(npoints);
	SCPPNT::Vector<Real> points(npoints);
	DiscreteNormalDist(npoints, -4.0, 4.0, points.begin(), weights.begin());
	
	DiscreteLatentDist<Real>::point_iterator idp1 = dist.begin_points(1);
	DiscreteLatentDist<Real>::point_iterator idp2 = dist.begin_points(2);
	DiscreteLatentDist<Real>::weight_iterator idw1 = dist.begin_weights(1);
	DiscreteLatentDist<Real>::weight_iterator idw2 = dist.begin_weights(2);
	SCPPNT::Vector<Real>::iterator ip = points.begin();
	SCPPNT::Vector<Real>::iterator iw = weights.begin();
	
	int i;
	for (i = npoints; i--;)
	{
		*idp1++ = *ip;
		*idp2++ = *ip++;
		*idw1++ = *iw;
		*idw2++ = *iw++;
	}
	
	return dist;
}


/* 
	Estimate new weights for group 'group'. Use new weights to compute mean and s.d. for
	group, then transforms group points to produce this mean and s.d. using
	the original group weights.
	
	group = Group to compute new points for (1 or 2)

*/
void StandardizePoints(int group, DiscreteLatentDist<double> &latentDist, estep_type &estep)
{

	if (group != 1 && group != 2) throw etirm::RuntimeError("Invalid group", "StandardizePoints");

	DiscreteLatentDist<double> dist(latentDist);
	// Estimate new group weights
	RealVector eprob(estep.GetNGroup(group) , estep.GetNGroup(group) + estep.size());
	dist.MStep(eprob, group);
		
	/* Standardize latent distribution to have mean zero and s.d. 1 */
	Real mean,sd,oldmean,oldsd;
	latentDist.MeanSD(group,oldmean,oldsd);
	dist.MeanSD(group,mean, sd);
	
	Real slope = sd/oldsd;
	Real intercept = mean - slope * oldmean;
	
	/* Transform points of latent distribution for group 2 to be on new scale */
	int n = latentDist.size();
	DiscreteLatentDist<double>::point_iterator ip = latentDist.begin_points(group);
	while(n--)
	{
		*ip *= slope;
		*ip += intercept;
		++ip;
	}
	
}
	
} // unnamed namespace

/*
	Command line arguments:
	
	1. Number of items.
	2. Input file containing item responses.
	3. Output file.
	
*/
int main(int argc, char *argv[])
{

	// Container to hold Uncmin optimization objects
	typedef	std::vector<Uncmin<RealVector, RealMatrix, item_type> *> UncminVector;

	// If true discrete latent variable distribution is estimated with item parameters
	const bool estLatentDist = true;
	
	// Number of item parameters.
	// If this is changed then definition of item_type must also be changed.
	const int numParam = 3;

	// convergence criterion - Maximum relative difference in any item parameter
	// must be less than this for EM iterations to stop.
	const Real paramCrit = 0.001;
	
	// Maximum number of EM iterations
	const int maxIter = 100;
	
	int i, mFail;
	
	// check that there are three command line arguments
	// (first argument of argv array is the program name so
	// the total number of elements in argv is 4)
	if (argc != 4)
	{
		std::cerr << "Invalid number of arguments to program";
		return 0;
	}

	// Get number of items from first command line argument
	int numItems;
	if (std::sscanf(argv[1], "%d", &numItems) != 1)
	{
		std::cerr << "Invalid number of items";
		return 0;
	}

	// Get input and output files from second and third command line arguments
	const char *respFile = argv[2];
	const char *outFile = argv[3];


	std::FILE *resultFile = std::fopen(outFile,"w");
	if (!resultFile)
	{
		std::cerr << "Could not open output file\n";
		return 0;
	}
	
	/* Standard normal latent variable distribution */
	DiscreteLatentDist<Real> latentDist = LatentDistTwo(40);

	/* Read item responses for examinees */
	std::vector<examinee_type *> examinees;
	if (ReadExamineeItemResp(numItems, examinees, respFile))
	{
		std::cerr << "Error in reading item response file\n";
		return 0;
	}
	
	/* Create vector to hold information for each item */
	std::vector<item_type *> items(numItems);
	ICCLogistic<numParam> icc(1.7);
	for (i=0; i<numItems; i++) items[i] = new item3PL_type(i, icc, &latentDist);
	
	/* Priors for a, b, and c parameters. Same prior is used for all items */
	ItemParamPriorBeta4 *priorC = new ItemParamPriorBeta4(5.0,17.0, 0.0, 1.0);
	ItemParamPriorLogNormal *priorA = new ItemParamPriorLogNormal(0.0, 0.5);
	ItemParamPriorBeta4 *priorB = new ItemParamPriorBeta4(1.01, 1.01, -5.0, 5.0);

	/* Priors for starting values */
	PriorVector priors(numParam);

	/* Use priors on all parameter when computing starting values */
	priors[0] = priorA;
	priors[1] = priorB;
	priors[2] = priorC;
	for (i=0; i<numItems; i++) 
	{
		items[i]->SetPriors(priors);
	}

	/* Set up vector of Uncmin objects to use for optimization in M-step */
	UncminVector minProc(numItems);
	for (i=0; i<numItems; ++i)
	{
		minProc[i] = new Uncmin<RealVector, RealMatrix, item_type>(3);
	}

	/* Compute item parameter starting values */
	try {
	mFail = StartingValues3PL<examinee_type::response_iterator, UncminVector::iterator,
			 std::vector<examinee_type *>::iterator, item_type, std::vector<item_type *>::iterator>
		(minProc.begin(), examinees.begin(), examinees.end(), items.begin(), items.end(), 
			item3PL_type::NotPresentedResponse(), false);
	}
	catch (SCPPNT::Exception &error)
	{
		std::puts(error.what());
		std::abort();
	}

	if (mFail) 
	{
		std::cout << "Failure in computing starting values\n";
		std::fputs("Failure in computing starting values\n",resultFile);
		return 0;
	}

	/* set priors on a and c parameters only for EM iterations */
	priors[0] = priorA;
	priors[1] = 0;
	priors[2] = priorC;
	for (i=0; i<numItems; i++) 
	{
		items[i]->SetPriors(priors);
	}

	/* Create E-step object */
	estep_type	estep(items.begin(), items.end(), latentDist);
	
	double maxreldiff;
	// Compute E-step for starting values
	double marginalLL = estep.DoEStep(examinees.begin(), examinees.end(), true, false);
	for (int iter = 1; iter <=maxIter; iter++)
	{
		// M-step for item parameters
		mFail = MStepItems<UncminVector::iterator, std::vector<item_type *>::iterator >
			(minProc.begin(), items.begin(), items.end(), maxreldiff, true);
			
		if (mFail)
		{
			std::cout << "M-step failed at iteration " << iter << '\n';
			/* If mFail is positive this means an error other than the maximum number of 
			   iterations being exceeded was returned by MStepItems, so iterations are stopped */
			if (mFail > 0)
			{
				std::fprintf(resultFile, "M-step failed at iteration %d for item %d: %d\n", iter, mFail,
				minProc[mFail-1]->GetMessage());
				double gradtol, steptol;
				int iterations;
				minProc[mFail-1]->GetStoppingCriteria(gradtol, steptol, iterations);
				std::fprintf(resultFile, "Grad: %le  Step: %le  Iteration: %d\n", gradtol,
					steptol, iterations);
				break;
			}
			/* If mFail is negative this means the maximum number of iterations was exceeded
			   for one or more items. Report this, but continue iterations */
			else std::fprintf(resultFile, "Maximum number of M-step iterations exceeded for %d items\n",
				-mFail);
		}
		
		// M-step for latent variable distribution
		if (estLatentDist) 
		{
			StandardizePoints(1, latentDist, estep);
		}
		
		// next E-step
		marginalLL = estep.DoEStep(examinees.begin(), examinees.end(), true, false);
		
		// Print convergence criterion and marginal loglikelihood for iteration
		std::fprintf(resultFile, "Iteration %03d: %.6f", iter, maxreldiff);
		std::fprintf(resultFile, "%12.4f\n", marginalLL);

		// Print convergence criterion and marginal loglikelihood for iteration to screen
		std::printf("Iteration %03d: %.6f", iter, maxreldiff);
		std::printf("%12.4f\n", marginalLL);

		if (maxreldiff < paramCrit) break; // check for convergence
	}
	std::fputc('\n', resultFile); // insert blank line

	/* Print item parameter estimates */
	for (i = 0; i <numItems; ++i)
	{
		RealVector::iterator param = items[i]->ParametersIterator();
		
		for (int j = 0; j<3; j++)
		{
			std::fprintf(resultFile, "%.8lf", param[j]);
			if (j != 2) std::fputc('\t', resultFile);
		}
		std::fputc('\n', resultFile);
	}
	
	/* Print latent variable distribution if it was estimated */
	if (estLatentDist)
	{
		for (int g=1; g<=2; ++g)
		{
			/* Write latent distribution points and weights */
			DiscreteLatentDist<Real>::point_iterator ip = latentDist.begin_points(g);
			DiscreteLatentDist<Real>::weight_iterator iw = latentDist.begin_weights(g);
			std::fputc('\n', resultFile);

			for (i=0; i< latentDist.size(); i++)
			{
				std::fprintf(resultFile, "%.6lf\t%.8lf\n", *ip++, *iw++);
			}
			std::fputc('\n', resultFile);
		}
	}
	
	std::fclose(resultFile);

	// Release memeory
	for (i=0; i<numItems; ++i)
	{
		delete minProc[i];
		delete items[i];
	}
	std::vector<examinee_type *>::iterator ie = examinees.begin();
	for (i=examinees.size(); i--; ++ie) delete *ie;
	delete priorA;
	delete priorB;
	delete priorC;

	return 0;
}
